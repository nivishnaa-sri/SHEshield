from django.contrib import admin
from .models import EmergencyContact, UnsafeArea

admin.site.register(EmergencyContact)
admin.site.register(UnsafeArea)

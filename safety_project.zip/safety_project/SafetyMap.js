import React, { useEffect, useState } from 'react';
import { APIProvider, Map } from '@visgl/react-google-maps';
import axios from 'axios';

const SafetyMap = () => {
    const [heatmapData, setHeatmapData] = useState([]);

    useEffect(() => {
        // Fetch coordinates from your Django HeatmapView
        axios.get('http://127.0.0.1:8000/api/heatmap/')
            .then(res => setHeatmapData(res.data))
            .catch(err => console.log(err));
    }, []);

    return (
        <APIProvider apiKey={'YOUR_GOOGLE_MAPS_KEY'}>
            <Map
                style={{ width: '100%', height: '400px' }}
                defaultCenter={{ lat: 12.97, lng: 77.59 }} // Set to your city
                defaultZoom={13}
                gestureHandling={'greedy'}
            />
            {/* The Heatmap layer would be added here as a sub-component */}
        </APIProvider>
    );
};